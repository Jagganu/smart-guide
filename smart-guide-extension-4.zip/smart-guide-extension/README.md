# ⚡ SmartGuide AI — Chrome Extension

An AI-powered assistant that **automatically analyzes every website** you visit — summarizing content pages or teaching you how to use tool/app pages.

---

## 🚀 How to Install

1. **Unzip** the `smart-guide-extension` folder anywhere on your computer.
2. Open Chrome and go to: `chrome://extensions`
3. Enable **Developer Mode** (toggle in the top-right corner).
4. Click **"Load unpacked"** → select the `smart-guide-extension` folder.
5. The extension icon (⚡) will appear in your toolbar.
6. Click it → enter your **Anthropic API key** (get one at [console.anthropic.com](https://console.anthropic.com)).

---

## ✨ Features

### 📄 Content Pages (articles, blogs, news, docs)
- **Summary** — 2–3 sentence overview of the page
- **Key Points** — Top 5 takeaways
- **Concepts Explained** — Jargon and difficult ideas explained simply
- **Ask Anything** — Chat about the content

### 🛠 Tool / App Pages (dashboards, editors, platforms)
- **What It Does** — What the tool is and its purpose
- **Key Features** — Top capabilities listed
- **How to Get Started** — Step-by-step workflow guide
- **Ask Anything** — "What does this button do?", "How do I export?", etc.

### 💬 Chat Mode
- Full conversation with memory
- Quick prompts based on page type
- Press **Enter** to send, **Shift+Enter** for new line

---

## 🔐 Privacy
- Your API key is stored **locally** in Chrome storage only
- Page content is sent to Anthropic's API for analysis (subject to their privacy policy)
- No data is stored on any external server by this extension

---

## 📁 File Structure

```
smart-guide-extension/
├── manifest.json      # Extension config
├── popup.html         # Extension UI
├── popup.js           # UI logic
├── content.js         # Page data extractor
├── background.js      # API calls (service worker)
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

---

## 🔧 Customization

To change the AI model or behavior, edit `background.js`:
- Line with `model: "claude-sonnet-4-20250514"` — swap model if needed
- `buildSystemPrompt()` — customize what the AI focuses on
- `max_tokens: 1024` — increase for longer responses

---

## ⚠️ Troubleshooting

| Issue | Fix |
|-------|-----|
| "Could not read page content" | Refresh the page, then click the extension |
| API error 401 | Check your API key in Settings (⚙) |
| Blank analysis | Some pages block content scripts; try a different page |
| Extension not appearing | Make sure Developer Mode is ON in chrome://extensions |
