// background.js — SmartGuide AI service worker (Gemini API)

// ─── Debug Logger ────────────────────────────────────────────────────────────
const DEBUG = true; // Set to false before publishing

function dbg(label, data) {
  if (!DEBUG) return;
  const time = new Date().toISOString().slice(11, 23);
  console.group(`%c[SmartGuide ${time}] ${label}`, "color:#7c6dff;font-weight:bold;");
  if (data !== undefined) console.log(data);
  console.groupEnd();
}

// ─── Message Listener ────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  dbg("Message received", { type: msg.type, sender: sender?.tab?.url });
  if (msg.type === "CALL_GEMINI") {
    callGemini(msg.payload)
      .then((result) => { dbg("Gemini response OK", result?.slice(0, 100) + "…"); sendResponse({ ok: true, data: result }); })
      .catch((err) => { dbg("Gemini response ERROR", err.message); sendResponse({ ok: false, error: err.message }); });
    return true; // keep channel open for async
  }
});

// ─── Gemini Models (tries in order until one works) ──────────────────────────
const GEMINI_MODELS = [
  "gemini-2.0-flash",
  "gemini-2.0-flash-lite",
  "gemini-1.5-flash",
  "gemini-1.5-flash-8b",
  "gemini-1.5-pro",
  "gemini-2.5-flash-preview-05-20",
  "gemini-2.5-pro-preview-05-06",
];

// ─── Gemini API Call (auto-fallback across models) ───────────────────────────
async function callGemini({ pageData, userQuestion, conversationHistory }) {
  const apiKey = await getApiKey();
  if (!apiKey) {
    dbg("ERROR: No API key found in storage");
    throw new Error("No API key set. Please enter your Gemini API key in Settings.");
  }

  const systemPrompt = buildSystemPrompt(pageData);
  const contents = buildGeminiContents(pageData, userQuestion, conversationHistory, systemPrompt);

  // Check if user selected a specific model or auto mode
  const { selectedModel } = await new Promise(res => chrome.storage.local.get("selectedModel", res));
  const modelsToTry = (!selectedModel || selectedModel === "auto")
    ? GEMINI_MODELS
    : [selectedModel, ...GEMINI_MODELS.filter(m => m !== selectedModel)]; // try selected first, then fallback

  dbg("Calling Gemini API", {
    pageType: pageData.pageType,
    url: pageData.url,
    question: userQuestion?.slice(0, 80),
    historyLength: conversationHistory?.length,
    bodyTextLength: pageData.bodyText?.length,
    uiElements: pageData.uiElements?.length,
    turns: contents.length,
    modelsToTry,
  });

  // Try each model in order until one succeeds
  let lastError = "";
  for (const model of modelsToTry) {
    try {
      dbg(`Trying model: ${model}`);
      const result = await callGeminiModel(apiKey, model, systemPrompt, contents);
      dbg(`Success with model: ${model}`);
      // Save the working model for next time
      chrome.storage.local.set({ lastWorkingModel: model });
      return result;
    } catch (err) {
      dbg(`Model ${model} failed`, err.message);
      lastError = err.message;
      // Only continue to next model if it's a quota/rate limit error
      const isQuotaError = err.message.includes("quota") ||
                           err.message.includes("rate") ||
                           err.message.includes("429") ||
                           err.message.includes("RESOURCE_EXHAUSTED");
      if (!isQuotaError) throw err; // Don't retry for auth/other errors
    }
  }

  throw new Error(`All Gemini models exhausted. Last error: ${lastError}`);
}

async function callGeminiModel(apiKey, model, systemPrompt, contents) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      system_instruction: { parts: [{ text: systemPrompt }] },
      contents,
      generationConfig: {
        maxOutputTokens: 1024,
        temperature: 0.7,
      },
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    dbg("Gemini HTTP error", { status: response.status, model, error: err });
    const msg = err?.error?.message || `Gemini API error ${response.status}`;
    throw new Error(msg);
  }

  const data = await response.json();
  dbg("Gemini model response", {
    model,
    finishReason: data.candidates?.[0]?.finishReason,
    tokenCount: data.usageMetadata,
  });

  return data.candidates?.[0]?.content?.parts?.[0]?.text || "";
}

// ─── Prompt Builders ─────────────────────────────────────────────────────────
function buildSystemPrompt(pageData) {
  if (pageData.pageType === "tool") {
    return `You are SmartGuide AI, an expert assistant embedded in a Chrome extension.
The user is viewing a TOOL/APP website: "${pageData.title}" (${pageData.url}).

Your job:
1. Explain what this tool does and its key features
2. Describe what each button, input, and section does
3. Guide the user through common workflows step by step
4. Answer any question about how to use this tool

UI elements detected on this page:
${pageData.uiElements.map((e) => `- [${e.type}] ${e.label}`).join("\n") || "None detected"}

Page content excerpt:
${pageData.bodyText.slice(0, 3000)}

Be practical, clear, and numbered when giving steps. Use simple language. Format with short paragraphs.`;
  }

  return `You are SmartGuide AI, an expert assistant embedded in a Chrome extension.
The user is viewing a CONTENT page: "${pageData.title}" (${pageData.url}).

Your job:
1. Summarize the page content clearly and concisely
2. Extract the key points (max 5 bullets)
3. Explain any jargon, complex ideas, or technical terms simply
4. Answer any question about the content

Page content:
${pageData.bodyText.slice(0, 4000)}

Be informative but concise. Use plain language. Format clearly.`;
}

function buildGeminiContents(pageData, userQuestion, conversationHistory, systemPrompt) {
  const contents = [];

  // Gemini uses "user" / "model" roles (not "assistant")
  if (conversationHistory && conversationHistory.length > 0) {
    for (const msg of conversationHistory) {
      contents.push({
        role: msg.role === "assistant" ? "model" : "user",
        parts: [{ text: msg.content }],
      });
    }
  } else {
    // First turn — auto-analyze the page
    const autoPrompt =
      pageData.pageType === "tool"
        ? "Please explain what this tool/app is, what its main features are, and how I can get started using it."
        : "Please summarize this page, give me the key points, and highlight anything complex I should understand.";
    contents.push({ role: "user", parts: [{ text: autoPrompt }] });
  }

  // Add current user question if present
  if (userQuestion) {
    contents.push({ role: "user", parts: [{ text: userQuestion }] });
  }

  return contents;
}

// ─── Storage ─────────────────────────────────────────────────────────────────
async function getApiKey() {
  return new Promise((resolve) => {
    chrome.storage.local.get("apiKey", (result) => {
      resolve(result.apiKey || "");
    });
  });
}
