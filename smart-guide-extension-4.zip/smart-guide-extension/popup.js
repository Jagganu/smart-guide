// popup.js — SmartGuide AI popup logic

const DEBUG = true;
const debugLogs = [];

function dbg(label, data) {
  if (!DEBUG) return;
  const time = new Date().toISOString().slice(11, 19);
  const entry = { time, label, data };
  debugLogs.push(entry);
  console.log(`%c[SmartGuide:popup ${time}] ${label}`, "color:#7c6dff;font-weight:bold;", data ?? "");
  renderDebugPanel();
}

function renderDebugPanel() {
  const el = document.getElementById("debug-log");
  if (!el) return;
  el.innerHTML = debugLogs.slice(-30).reverse().map(e => `
    <div class="debug-entry">
      <span class="debug-time">${e.time}</span>
      <span class="debug-label">${e.label}</span>
      ${e.data !== undefined ? `<pre class="debug-data">${JSON.stringify(e.data, null, 2)}</pre>` : ""}
    </div>
  `).join("");
}

let pageData = null;
let pageType = "content";
let conversationHistory = [];
let analysisCache = null;

// ─── Init ────────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  const apiKey = await getStoredKey();
  if (!apiKey) {
    showScreen("api");
  } else {
    showScreen("main");
    initMain();
  }

  // API Key save
  document.getElementById("save-key-btn").addEventListener("click", async () => {
    const key = document.getElementById("api-key-input").value.trim();
    if (!key.startsWith("AIza")) return alert("Please enter a valid Gemini API key (starts with AIza...)");
    await storeKey(key);
    showScreen("main");
    initMain();
  });

  // Settings toggle
  document.getElementById("settings-toggle").addEventListener("click", toggleSettings);

  // Update key from settings
  document.getElementById("update-key-btn").addEventListener("click", async () => {
    const key = document.getElementById("settings-api-input").value.trim();
    if (!key.startsWith("AIza")) return alert("Please enter a valid Gemini API key (starts with AIza...)");
    await storeKey(key);
    // Save selected model
    const model = document.getElementById("model-select").value;
    await chrome.storage.local.set({ selectedModel: model });
    analysisCache = null; // force re-analysis with new model
    alert("Settings saved!");
  });

  // Load saved model selection
  chrome.storage.local.get(["selectedModel"], (r) => {
    if (r.selectedModel) {
      const sel = document.getElementById("model-select");
      if (sel) sel.value = r.selectedModel;
    }
  });

  // Clear key
  document.getElementById("clear-key-btn").addEventListener("click", async () => {
    await chrome.storage.local.remove("apiKey");
    location.reload();
  });

  // Tabs
  document.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      const target = tab.dataset.tab;
      document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
      document.querySelectorAll(".tab-content").forEach((p) => p.classList.remove("active"));
      tab.classList.add("active");
      document.getElementById(`panel-${target}`).classList.add("active");
      document.getElementById("panel-settings").classList.remove("active");
    });
  });

  // Chat send
  document.getElementById("send-btn").addEventListener("click", sendChat);
  document.getElementById("chat-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendChat();
    }
  });
});

async function initMain() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) { dbg("ERROR: No active tab found"); return; }

    const url = new URL(tab.url);
    document.getElementById("page-url-label").textContent = url.hostname;
    dbg("Active tab", { url: tab.url, tabId: tab.id });

    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] }).catch((e) => dbg("Script inject warning", e.message));

    pageData = await chrome.tabs.sendMessage(tab.id, { type: "GET_PAGE_DATA" }).catch((e) => { dbg("Content script error", e.message); return null; });

    if (!pageData) {
      dbg("ERROR: pageData is null");
      showAnalysisError("Could not read page content. Try refreshing the page.");
      return;
    }

    dbg("Page data received", {
      pageType: pageData.pageType,
      title: pageData.title,
      bodyTextLength: pageData.bodyText?.length,
      uiElements: pageData.uiElements?.length,
    });

    pageType = pageData.pageType;

    const badge = document.getElementById("page-type-badge");
    badge.textContent = pageType === "tool" ? "🛠 Tool" : "📄 Content";
    badge.className = `page-badge ${pageType}`;

    setQuickPrompts(pageType);
    await runAnalysis();
  } catch (err) {
    dbg("initMain ERROR", err.message);
    showAnalysisError("Extension error: " + err.message);
  }
}

// ─── Analysis ─────────────────────────────────────────────────────────────────
async function runAnalysis() {
  if (analysisCache) {
    dbg("Using cached analysis");
    renderAnalysis(analysisCache);
    return;
  }

  dbg("Starting page analysis", { pageType });
  const prompt =
    pageType === "tool"
      ? `Analyze this tool/app page and respond ONLY in this exact JSON format (no markdown):
{
  "summary": "2-3 sentence description of what this tool does",
  "keypoints": ["feature or capability 1", "feature or capability 2", "feature or capability 3", "feature or capability 4", "feature or capability 5"],
  "extras": "Step-by-step: How to get started with this tool in 3-4 numbered steps. Then list 2-3 power tips."
}`
      : `Analyze this content page and respond ONLY in this exact JSON format (no markdown):
{
  "summary": "2-3 sentence summary of the main topic and argument",
  "keypoints": ["key point 1", "key point 2", "key point 3", "key point 4", "key point 5"],
  "extras": "Explain any difficult concepts, jargon, or technical terms found in this content. Use simple language."
}`;

  const result = await callClaude(prompt, true);
  if (!result) return;

  try {
    const clean = result.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);
    dbg("Analysis JSON parsed OK", { keys: Object.keys(parsed) });
    analysisCache = parsed;
    renderAnalysis(parsed);
  } catch (e) {
    dbg("JSON parse failed, using raw text", e.message);
    document.getElementById("summary-body").textContent = result;
    document.getElementById("keypoints-body").textContent = "";
    document.getElementById("extras-body").textContent = "";
  }
}

function renderAnalysis(data) {
  document.getElementById("summary-body").textContent = data.summary || "No summary available.";

  const kpEl = document.getElementById("keypoints-body");
  if (Array.isArray(data.keypoints) && data.keypoints.length) {
    kpEl.textContent = data.keypoints.map((k, i) => `${i + 1}. ${k}`).join("\n");
  } else {
    kpEl.textContent = data.keypoints || "";
  }

  document.getElementById("extras-body").textContent = data.extras || "";

  const extrasLabel = document.getElementById("extras-label");
  extrasLabel.textContent =
    pageType === "tool" ? "🚀 How to Get Started" : "💡 Concepts Explained";
}

// ─── Chat ─────────────────────────────────────────────────────────────────────
function setQuickPrompts(type) {
  const prompts =
    type === "tool"
      ? ["What does this do?", "Explain the buttons", "Common workflow", "How do I start?", "Any tips?"]
      : ["Explain simply", "What's the main idea?", "What's controversial?", "Key takeaways", "Any bias?"];

  const container = document.getElementById("quick-prompts");
  container.innerHTML = "";
  prompts.forEach((p) => {
    const btn = document.createElement("button");
    btn.className = "qp-btn";
    btn.textContent = p;
    btn.addEventListener("click", () => {
      document.getElementById("chat-input").value = p;
      sendChat();
    });
    container.appendChild(btn);
  });
}

async function sendChat() {
  const input = document.getElementById("chat-input");
  const question = input.value.trim();
  if (!question) return;

  input.value = "";
  addMessage("user", question);
  const typingEl = showTyping();

  const reply = await callClaude(question, false);
  typingEl.remove();

  if (reply) {
    addMessage("ai", reply);
    conversationHistory.push({ role: "user", content: question });
    conversationHistory.push({ role: "assistant", content: reply });
    // Keep history bounded
    if (conversationHistory.length > 20) conversationHistory = conversationHistory.slice(-20);
  } else {
    addMessage("ai", "Sorry, I couldn't get a response. Check your API key in Settings.");
  }
}

function addMessage(role, text) {
  const container = document.getElementById("chat-messages");
  const div = document.createElement("div");
  div.className = `msg ${role}`;
  div.innerHTML = `
    <div class="msg-avatar">${role === "user" ? "👤" : "⚡"}</div>
    <div class="msg-bubble">${escapeHtml(text)}</div>
  `;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

function showTyping() {
  const container = document.getElementById("chat-messages");
  const div = document.createElement("div");
  div.className = "msg ai";
  div.innerHTML = `
    <div class="msg-avatar">⚡</div>
    <div class="msg-bubble"><span class="typing-dots"><span></span><span></span><span></span></span></div>
  `;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
  return div;
}

// ─── Claude API call (via background) ────────────────────────────────────────
async function callClaude(userQuestion, isFirstAnalysis) {
  if (!pageData) { dbg("ERROR: callClaude called with no pageData"); return null; }

  dbg("Sending to background", { isFirstAnalysis, question: userQuestion?.slice(0, 60) });
  document.getElementById("send-btn").disabled = true;

  try {
    const history = isFirstAnalysis ? [] : conversationHistory;
    const response = await chrome.runtime.sendMessage({
      type: "CALL_GEMINI",
      payload: { pageData, userQuestion, conversationHistory: history },
    });

    if (!response.ok) {
      dbg("Background returned error", response.error);
      if (isFirstAnalysis) showAnalysisError(response.error);
      return null;
    }
    dbg("Got Claude reply", { length: response.data?.length });
    return response.data;
  } catch (err) {
    dbg("Runtime message error", err.message);
    return null;
  } finally {
    document.getElementById("send-btn").disabled = false;
  }
}

// ─── Settings ────────────────────────────────────────────────────────────────
let settingsOpen = false;

function toggleSettings() {
  settingsOpen = !settingsOpen;
  const settingsPanel = document.getElementById("panel-settings");
  const tabBar = document.getElementById("tab-bar");

  if (settingsOpen) {
    document.querySelectorAll(".tab-content").forEach((p) => p.classList.remove("active"));
    settingsPanel.classList.add("active");
    tabBar.style.opacity = "0.4";
    tabBar.style.pointerEvents = "none";
  } else {
    settingsPanel.classList.remove("active");
    document.getElementById("panel-analysis").classList.add("active");
    document.querySelector('.tab[data-tab="analysis"]').classList.add("active");
    tabBar.style.opacity = "";
    tabBar.style.pointerEvents = "";
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
function showScreen(name) {
  document.getElementById("api-screen").classList.toggle("hidden", name !== "api");
  document.getElementById("main-screen").classList.toggle("hidden", name !== "main");
}

function showAnalysisError(msg) {
  ["summary-body", "keypoints-body", "extras-body"].forEach((id) => {
    document.getElementById(id).innerHTML = `<div class="error-msg">⚠ ${msg}</div>`;
  });
}

function getStoredKey() {
  return new Promise((res) => chrome.storage.local.get("apiKey", (r) => res(r.apiKey || "")));
}

function storeKey(key) {
  return new Promise((res) => chrome.storage.local.set({ apiKey: key }, res));
}

function escapeHtml(text) {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
